const express = require("express")//لا يسمح ب التعديل
const app = express()// لا يسمح بالتعديل

const { AutoKill } = 
require('autokill');//لا يسمح ب التعديل

const { Probot } = require('discord-probot-transfer')//لا يسمح ب التعديل

const axios = require("axios")//لا يسمح ب التعديل

const db = require('pro.db')//لا يسمح ب التعديل

const { Client, Events, GatewayIntentBits, ButtonBuilder, ButtonStyle,SlashCommandBuilder, ActionRowBuilder,EmbedBuilder, SelectMenuBuilder,ChannelType,ActivityType} = require('discord.js')//يسمح بالاضافة و التعديل


const client = new Client({
	intents: [
		GatewayIntentBits.Guilds,
		GatewayIntentBits.GuildMessages,
		GatewayIntentBits.MessageContent,
		GatewayIntentBits.GuildMembers,
	],
});//يسمح بالاضافة و التعديل


const { prefix } = require('./config.json')//يسمح بالتعديل و الاضافة على حسب الاحتياج

client.once(Events.ClientReady,c => {
  console.log(`login in ${c.user.tag}`)
  console.log(`my prefix is ${prefix}`)
client.user.setPresence({ activities: [{ name: `discord.gg/rtx-s1`, type: 1 }], status: 'dnd', url:`https://www.twitch.tv/kaicenat` })//يسمح بالتعديل
app.get('/', (req, res) => {
  res.send("by ")//يسمح بالتعديل هنا فقط
})
app.listen(3000, () => {
  console.log('express is ready');//يسمح بالتعديل هنا فقط
});
});

          //
         //==============
        //
       //ativities :
      //ActivityType.Competing =	5
     //ActivityType.Custom	 = 4
    //ActivityType.Listening =	2
   //ActivityType.Playing	= 0
  //ActivityType.Streaming =	1
 //ActivityType.Watching =	3
//
  //
    // status :
      // idle
        // invisible
          // online
             // dnd
                // ==============


process.on("uncaughtException" , error => {
return;
})//لا يسمح ب التعديل

process.on("unhandledRejection" , error => {
return;
})//لا يسمح ب التعديل

process.on("rejectionHandled", error => {
return;
});//لا يسمح ب التعديل

AutoKill({ Client: client, Time: 10000 }); //لا يسمح ب التعديل

// نزل الاكواد سطر 79 
//اصدار 14 اهم شي اي اصدار اخر ما رح يشتغل


///say
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === "say") {
    try {
      const text = args.join(' ');
      if (!text) {
        return message.reply('ي عم اكتب رسالة طيب متجبليش شلل.');
      }

      await message.channel.send(text);
      await message.delete();
    } catch (error) {
      console.error(error);
    }
  }

  // يمكنك إضافة أكواد أخرى هنا بنفس الحدث بدون `client.on`
});
const feedbackRoomID = "1253041378368159845"
client.on("messageCreate" , async(message) => {
    if(message.author.bot) return;
    if (message.channel.id === feedbackRoomID) {
        const embed = new EmbedBuilder()
                            .setAuthor({name : message.author.username , iconURL : message.author.displayAvatarURL({dynamic : true})})
                            .setThumbnail(message.author.displayAvatarURL({dynamic : true}))
                            .setFooter({text : message.author.username , iconURL : message.author.displayAvatarURL({dynamic : true})})
                            .setTimestamp()
                            .setDescription(`> <a:emoji:1260286328906448958> **__Thanks For Giving Us Feedback__** <a:emoji:1260286328906448958>
                            \n > <a:emoji:1260286328906448958> **__Hope You Visit Us Again__** <a:emoji:1260286328906448958> `)
                            .setImage(line);
        message.channel.send({embeds : [embed]})
    }
})
///تغيير اسم البوت
let owner = ""; ///اشخاص المسموح لهم باستخدام الامر
client.on("messageCreate", General => {
    if(General.content.startsWith(prefix+"rename")){
        if(General.author.id !== owner) 
     return General.reply(`لا تمتلك الرتبة`);
        let name = General.content.split(" ").slice(1).join(" ");
        if(!name) return General.reply("❌ اكتب الاسم الجديد من فضلك")
        client.user.setUsername(name);
     General.reply(`**تم تغيير اسم البوت الى ✅ ${name}**`);
    } 
}) 

///ضريبة 
const TaxChannel = ["1253041385167257712"]; // tax room ID

client.on("messageCreate", message => {
  if(message.author.bot) return;

  if (TaxChannel.includes(message.channel.id)) {
    let args = message.content.split(' ')[0];
    if (!args) return;

    if (args.endsWith("m")) args = args.replace(/m/gi, "") * 1000000;
    else if (args.endsWith("k") || args.endsWith("K")) args = args.replace(/[kK]/gi, "") * 1000;
    let args2 = parseInt(args);
    let tax = Math.floor(args2 * (20 / 19) + 1);

    message.reply(`> <a:emoji:1259618413593100349> **Your tax is: ${tax}**`);
  }
});

/// خط امر 
client.on("messageCreate", Aaa  => {
  if(Aaa.content ==  "خط") {
let role_id = "1253040928562741339" // الرول المسموح لها باستخدام الامر
let owner = ["999064730801029280", "851844710263554058"] // الاشخاص المسموح لهم باستخدام الامر
const link ="https://media.discordapp.net/attachments/1253041378368159845/1260279651780136960/Copy_of_Copy_of_Untitled_Design-12.png?ex=668ebe63&is=668d6ce3&hm=44d529df18dac8307f929c4a9895ac69664a9f4bed1b4452dd22663831b212a1&=&format=webp&quality=lossless&width=1295&height=82"  // لينك الخط
if(!Aaa.member.roles.cache.has(role_id))
if(!owner.includes(Aaa.author.id)) return Aaa.channel.send({ embeds: [new EmbedBuilder().setDescription(`عفواً ليس لديك صلاحيات `)] }).then(m =>{
  setTimeout(() => m.delete().catch(e =>{return console.log(`message delte`)}), 3000) 
  setTimeout(() => Aaa.delete().catch(e =>{return console.log(`message delte`)}), 3000)
 })
 Aaa.channel.send(link),Aaa.delete()
  }})

///come
const ADMIN_ROLE = '1253040959856578680' // حط ايدي رتبة الادارة اللي تقدر تستعمل الامر
client.on('messageCreate', async (message) => {
if(message.content.startsWith(prefix + 'come')) {
     if (message.author.bot) {
       return ;
    }
    const id = message.content.slice(0).trim().split(/ +/);
    let user = message.mentions.members.first() || message.guild.members.cache.get(id[1])
     if (!message.member.roles.cache.has(ADMIN_ROLE)) {
      return message.reply('هذا الأمر مخصص للإدارة فقط.')
    };
    if(!user) return message.reply('الرجاء منشن الشخص بعد كتابة الأمر.')
    user.send({ content: `** > <a:emoji:1259493899232084009> Some One Need You ${user}
    
> <a:emoji:1259493899232084009> Channel Here : <#${message.channel.id}>

> <a:emoji:1259493899232084009> I Hope You Enter To See What He Want **` })
   message.channel.send(`**\n\n > Done Send Private to ${user}  
>    
> Please Wait Until He Comes **`)
}
});


// كود خط تلقائي
let autoline_channel = ['1253041386006253601','1253041377097289748','1254132748554076291','1254136676498804746','1258804252550234154',] // ايدي الروم (تقدر تضيف اكثر من روم)
let line = `https://media.discordapp.net/attachments/1259290135179165706/1259940119960358952/Copy_of_Copy_of_Untitled_Design-12.png?ex=668e2aed&is=668cd96d&hm=88587cbe330a71aedff8f20a9a85af23558a36c7bcfb4ab51b7b05717b3210c6&=&format=webp&quality=lossless&width=1295&height=82`//رابط الخط

client.on(`messageCreate`, async message => {
        if(message.channel.type === "DM"|| message.author.bot) return
        if(autoline_channel.includes(message.channel.id)) {
                message.channel.send({files : [line]})
        }
})


///ping
client.on("messageCreate", async (message) => {
  if (message.content === prefix + "uptime") {
    let days = Math.floor(client.uptime / 86400000);
    let hours = Math.floor(client.uptime / 3600000) % 24;
    let minutes = Math.floor(client.uptime / 60000) % 60;
    let seconds = Math.floor(client.uptime / 1000) % 60;
    const uptimeString = `${days} days, ${hours} hours, ${minutes} minutes, ${seconds} seconds`;

    const ping = Date.now() - message.createdTimestamp;

    let color;

    if (ping < 100) {
      color = "#00FF00";
    } else if (ping < 200) {
      color = "#FFFF00";
    } else {
      color = "#FF0000";
    }

    let emoji;

    if (ping < 100) {
      emoji = "🟢";
    } else if (ping < 200) {
      emoji = "🟡";
    } else {
      emoji = "🔴";
    }

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle("Bot Uptime & Ping:")
      .addFields("Uptime", `**${uptimeString}**`, true)
      .addField("Ping", `**${emoji} ${ping}ms**`, false)
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
});


///help

const Discord = require('discord.js')
client.on('messageCreate' , async(msg) => {
  if(msg.content === prefix + 'help') {
    const embed = new Discord.EmbedBuilder()
    .setTitle('Help')
    .setDescription('قائمة اوامر البوت')

    const row = new Discord.ActionRowBuilder()
       .addComponents(
         new Discord.ButtonBuilder()
         .setLabel('Generale')
         .setStyle(Discord.ButtonStyle.Primary)
         .setCustomId('generale'),

         new Discord.ButtonBuilder()
         .setLabel('Admin')
         .setStyle(Discord.ButtonStyle.Success)
         .setCustomId('admin')
       )

    msg.reply({ embeds: [embed] , components: [row]})
  }
})

client.on('interactionCreate' , async(interaction) => {
  if(interaction.isButton()) {
    if(interaction.customId === 'generale') {
      const embed = new Discord.EmbedBuilder()
      .setTitle('Generale')
      .setDescription(`
      ${prefix}selle لااضهار المنيو
      ${prefix}uptime لرئية كم اله البوت شغال
      `)
      .setFooter({ text: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true})})

      interaction.reply({ embeds: [embed] , ephemeral: true})
    }
  }
})

client.on('interactionCreate' , async(interaction) => {
  if(interaction.isButton()) {
    if(interaction.customId === 'admin') {
      const embed = new Discord.EmbedBuilder()
      .setTitle('Admin')
      .setDescription(`
      ${prefix}rename لتغيير اسم البوت
      ${prefix}come لنداء شخص
      ${prefix}set-avatar لتغيير صورة البوت
      ${prefix}say للكتابة بلبوت
      `)
      .setFooter({ text: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true})})

      interaction.reply({ embeds: [embed] , ephemeral: true})
    }
  }
})

///
// كود رياكشن تلقائي
let autoreact_channel = [''] // ايدي الروم (تقدر تضيف اكثر من روم)
client.on('messageCreate', async message => {
        if(message.channel.type === 'DM' || message.author.bot) return //fxdark1.
        if(autoreact_channel.includes(message.channel.id)) { //fxdark1.
   message.react('✅') // تقدر تعدل على الايموجي
   message.react('❌') // تقدر تضيف اكثر من ايموجي عن طريق اضافة هذا السطر
        }
})


// كود يحول اي رسالة في الروم الى ايمبد
const embed_channels = ["1253041317768855643"];  //تقدر تضيف اكثر من روم
let e_line = `https://media.discordapp.net/attachments/1259290135179165706/1259940119960358952/Copy_of_Copy_of_Untitled_Design-12.png?ex=668e2aed&is=668cd96d&hm=88587cbe330a71aedff8f20a9a85af23558a36c7bcfb4ab51b7b05717b3210c6&=&format=webp&quality=lossless&width=1295&height=82`; //رابط الخط
client.on("messageCreate", async (message) => {
  if (message.author.bot || message.channel.type === "DM") return; //fxdark1.
  if (embed_channels.includes(message.channel.id)) {
    let embed = new EmbedBuilder() //fxdark1.
      .setAuthor({
        name: `${message.author.username}`,
        iconURL: `${message.author.displayAvatarURL({ dynamic: true })}`,
      }) //fxdark1.
      .setThumbnail(`${message.author.displayAvatarURL({ dynamic: true })}`)
      .setDescription(`${message.content}`) //fxdark1.
      .setColor('Random')
      .setTimestamp(); //fxdark1.
    message.delete().then(async () => {
      await message.channel.send({ embeds: [embed] })
      await message.channel.send({files : [e_line]})
    });
  }
});


///

client.on("messageCreate", async (message) => {
    if (message.content.startsWith(prefix + "set-avatar")) {
        if (message.author.id !== "") return; /// ايدي الي يقدر يغير الصورة

        const args = message.content.split(" ");
        if (!args[1]) return message.reply("Avatar Link required");

        try {
            await client.user.setAvatar(args[1]);
            message.reply({ embeds: [
                new MessageEmbed()
                    .setTitle('تم تغيير صورة البوت')
                    .setImage(args[1])
                    .setColor('GREEN')
            ]});
        } catch (err) {
            message.reply("تم تغيير صوره بنجاح.");
            console.error(err);
        }
    }
});

///سيلكة منيو
client.on('messageCreate', async (message) => {
  if (message.content.startsWith(prefix +`selle`)) {
    const row = new ActionRowBuilder()
      .addComponents(
        new SelectMenuBuilder()
          .setCustomId('select')
          .setPlaceholder('اضغط على القائمة للاختيار')
          .addOptions([
            {
              label: 'الرتب العادية',  
              value: 'option1',

            },
            {
              label: 'الرتب النادرة',
              value: 'option2',

            },
            {
              label: 'الرومات الخاصة',
              value: 'option3',

            },
            {
              label: 'الاعلانات',
              value: 'option4',

            },
            {
              label: 'المنشورات',
              value: 'option5',

            },
            {
              label: 'الاضافات',
              value: 'option6',



            }
          ]),
      );

    const embed = new EmbedBuilder()
      .setTitle('wthwt')
      .setDescription(`=eht`)
      .setColor('#11806a')
    await message.channel.send({ embeds: [embed], components: [row] });
  }
});
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isSelectMenu()) return;

  const selectedValue = interaction.values[0];

  switch (selectedValue) {
    case 'option1':
      const embed1 = new EmbedBuilder()
      .setColor('#11806a')
      .setTitle('الرتب العادية')
      .setDescription(`rgrsg`)
      await interaction.reply({ ephemeral: true, embeds: [embed1] });
      break;
    case 'option2':
    const embed2 = new EmbedBuilder()
      .setColor('#11806a')
      .setTitle('الرتب النادرة')
      .setDescription(`grege`)
      await interaction.reply({ ephemeral: true, embeds: [embed2] });
      break;
    case 'option3':
     const embed3 = new EmbedBuilder()
      .setColor('#11806a')
      .setTitle('الرومات الخاصة')
      .setDescription(`ergerg`)
      await interaction.reply({ ephemeral: true, embeds: [embed3] });
      break;
    case 'option4':
     const embed4 = new EmbedBuilder()
      .setColor('#11806a')
      .setTitle('معلومات الاعلانات')
      .setDescription(`ergegrerg`)
      await interaction.reply({ ephemeral: true, embeds: [embed4] });
      break;
    case 'option5':
     const embed5 = new EmbedBuilder()
      .setColor('#11806a')
      .setTitle('المنشورات المميزة')
      .setDescription(`wgrwwrg`)

      await interaction.reply({ ephemeral: true, embeds: [embed5] });
      break;
    case 'option6':
     const embed6 = new EmbedBuilder()
      .setColor('#11806a')
      .setTitle('الاضافات')
      .setDescription(`=rgg`)
      await interaction.reply({ ephemeral: true, embeds: [embed6]
});
  }


});
 

client.login(process.env.token).catch((error) => {
})